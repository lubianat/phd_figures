---
title: Manuscript Title
keywords:
- markdown
- publishing
- manubot
lang: en-US
date-meta: '2023-05-15'
author-meta:
- John Doe
- Jane Roe
header-includes: |-
  <!--
  Manubot generated metadata rendered from header-includes-template.html.
  Suggest improvements at https://github.com/manubot/manubot/blob/main/manubot/process/header-includes-template.html
  -->
  <meta name="dc.format" content="text/html" />
  <meta name="dc.title" content="Manuscript Title" />
  <meta name="citation_title" content="Manuscript Title" />
  <meta property="og:title" content="Manuscript Title" />
  <meta property="twitter:title" content="Manuscript Title" />
  <meta name="dc.date" content="2023-05-15" />
  <meta name="citation_publication_date" content="2023-05-15" />
  <meta name="dc.language" content="en-US" />
  <meta name="citation_language" content="en-US" />
  <meta name="dc.relation.ispartof" content="Manubot" />
  <meta name="dc.publisher" content="Manubot" />
  <meta name="citation_journal_title" content="Manubot" />
  <meta name="citation_technical_report_institution" content="Manubot" />
  <meta name="citation_author" content="John Doe" />
  <meta name="citation_author_institution" content="Department of Something, University of Whatever" />
  <meta name="citation_author_orcid" content="XXXX-XXXX-XXXX-XXXX" />
  <meta name="twitter:creator" content="@johndoe" />
  <meta name="citation_author" content="Jane Roe" />
  <meta name="citation_author_institution" content="Department of Something, University of Whatever" />
  <meta name="citation_author_institution" content="Department of Whatever, University of Something" />
  <meta name="citation_author_orcid" content="XXXX-XXXX-XXXX-XXXX" />
  <link rel="canonical" href="https://lubianat.github.io/fapesp_report_3/" />
  <meta property="og:url" content="https://lubianat.github.io/fapesp_report_3/" />
  <meta property="twitter:url" content="https://lubianat.github.io/fapesp_report_3/" />
  <meta name="citation_fulltext_html_url" content="https://lubianat.github.io/fapesp_report_3/" />
  <meta name="citation_pdf_url" content="https://lubianat.github.io/fapesp_report_3/manuscript.pdf" />
  <link rel="alternate" type="application/pdf" href="https://lubianat.github.io/fapesp_report_3/manuscript.pdf" />
  <link rel="alternate" type="text/html" href="https://lubianat.github.io/fapesp_report_3/v/22a1ea711b5ba21b8fd8372825f3c6e8559deed0/" />
  <meta name="manubot_html_url_versioned" content="https://lubianat.github.io/fapesp_report_3/v/22a1ea711b5ba21b8fd8372825f3c6e8559deed0/" />
  <meta name="manubot_pdf_url_versioned" content="https://lubianat.github.io/fapesp_report_3/v/22a1ea711b5ba21b8fd8372825f3c6e8559deed0/manuscript.pdf" />
  <meta property="og:type" content="article" />
  <meta property="twitter:card" content="summary_large_image" />
  <link rel="icon" type="image/png" sizes="192x192" href="https://manubot.org/favicon-192x192.png" />
  <link rel="mask-icon" href="https://manubot.org/safari-pinned-tab.svg" color="#ad1457" />
  <meta name="theme-color" content="#ad1457" />
  <!-- end Manubot generated metadata -->
bibliography:
- content/manual-references.json
manubot-output-bibliography: output/references.json
manubot-output-citekeys: output/citations.tsv
manubot-requests-cache-path: ci/cache/requests-cache
manubot-clear-requests-cache: false
...






<small><em>
This manuscript
([permalink](https://lubianat.github.io/fapesp_report_3/v/22a1ea711b5ba21b8fd8372825f3c6e8559deed0/))
was automatically generated
from [lubianat/fapesp_report_3@22a1ea7](https://github.com/lubianat/fapesp_report_3/tree/22a1ea711b5ba21b8fd8372825f3c6e8559deed0)
on May 15, 2023.
</em></small>

## Authors



+ **John Doe**<br>
    ![ORCID icon](images/orcid.svg){.inline_icon}
    [XXXX-XXXX-XXXX-XXXX](https://orcid.org/XXXX-XXXX-XXXX-XXXX)
    · ![GitHub icon](images/github.svg){.inline_icon}
    [johndoe](https://github.com/johndoe)
    · ![Twitter icon](images/twitter.svg){.inline_icon}
    [johndoe](https://twitter.com/johndoe)<br>
  <small>
     Department of Something, University of Whatever
     · Funded by Grant XXXXXXXX
  </small>

+ **Jane Roe**<br>
    ![ORCID icon](images/orcid.svg){.inline_icon}
    [XXXX-XXXX-XXXX-XXXX](https://orcid.org/XXXX-XXXX-XXXX-XXXX)
    · ![GitHub icon](images/github.svg){.inline_icon}
    [janeroe](https://github.com/janeroe)<br>
  <small>
     Department of Something, University of Whatever; Department of Whatever, University of Something
  </small>



UNIVERSIDADE DE SÃO PAULO
FACULDADE DE CIÊNCIAS FARMACÊUTICAS
Departamento de Análises Clínicas e Toxicológicas








Doctorate Project - Report 2
FAPESP process number: #2019/26284-1
Project term: 01/08/2020 to 31/07/2024
Period of Scientific report: 10/07/2022 to 10/07/2023


Scholarship Holder: Tiago Lubiana

Responsible Researcher: Prof. Dr. Helder Takashi Imoto Nakaya

São Paulo - SP
July 2022


# Abstract {.page_break_before}
The Human Cell Atlas (HCA) is an international effort to characterize every cell type of the human body. 
HCA members are producing cell-level data from virtually all human tissue using techniques such as single-cell RNA sequencing, mass cytometry, and multiplexed in situ hybridizations. 
The wealth knowledge stemming from the wealth of data needs management to maximize the societal benefit of HCA.
While semantic technologies have emerged as key players in the data interoperability ecosystem, there are still gaps to bridge. 
Wikidata, a sister project of Wikipedia for structured data, is surfacing as a hub in the semantic web for multiple types of information and bridging experts and the people. 
The connection of the Human Cell Atlas to Wikidata can quickly insert its products into the larger knowledge ecosystem, extending HCA's reach. 
This PhD project aims at studying Wikidata as a platform for representing cell types.  
To optimize the curation, we developed Wikidata Bib, a framework for literature management and organized note-taking system for dealing with the academic literature.
Using Wikidata Bib, we reviewed the specialized literature and manually curated thousands of cell classes into structured format in Wikidata. 
In parallel, we've mapped thousands of terms in the Cell Ontology into the Wikidata infrastructure, and are working on the connection of Wikidata into Cell Ontology workflows, as a step to connect this curation with the daily activity of curators in the Human Cell Atlas. 
Finally, we explore the linked open data infrastructure of Wikidata to build metascientific knowledge graphs of the bioinformatics community, showcasing its applications beyond the representation of scientific concepts and into the inner workings of science.

# Project summary  {.page_break_before}

The advent of single-cell technologies has deepened the scientific community's interest in the building blocks of life, the cells [@wikidata:Q99418649]. 
The Human Cell Atlas (HCA) project, has been a major player in the cell knowledge ecosystem, running since 2017 towards the task to characterize every cell type in the human body [@wikidata:Q46368626]. The HCA consortium recruited people from all over the world to tackle different parts of the project. In Brazil, Prof. Helder Nakaya (supervisor of this PhD project) is playing a key role the national effort to contribute to HCA, with a focus on the roles of different cell types in the pathological processes of infectious and inflammatory diseases.

HCA is revolutionizing the biomedical sciences, by creating tools and standards for basic research, as well as allowing better characterization of disease, and thus, ultimately, improving diagnostics and therapy. 
Its products (data, information, knowledge and wisdom) need to be FAIR: findable, accessible, interoperable and reusable.
Data stewardship and data management are growing as core demands of the scientific community, ranging from data management plans [@wikidata:Q56524391] to specialized personnel [@wikidata:Q56524391].

The Human Cell Atlas has a dedicated team for organizing data: the Data Coordination Platform (DCP) [@url:https://data.humancellatlas.org/about] [@wikidata:Q104450645].
The DCP is responsible for tracing the plan for computational interoperability, from the data generators to the consumers.[@wikidata:Q104450645].In addition to its core team, the HCA is poised to grow by community interaction, and states in its opening paper that "As with the Human Genome Project, a robust plan will best emerge from wide-ranging scientific discussions and careful planning".[@wikidata:Q46368626]  
Thus, this project inserts itself among the wide-ranging scientific discussions to improve data - and knowledge - interoperability. 

The large amount of information generated by HCA creates the need for efficient knowledge management approaches. One of them is the wide appliation of ontologies to annotate datasets and summarize information, with a key role of the Cell Ontology (the ontology of cell types) in the ecosystem. [@wikidata:Q109755180]. For example, cellxgene  is a leading platform for single-cell RNA-seq data analysis from the Chan Zuckerberg Initiative, and it employs OBO Foundry ontologies 
to standardize annotations of cell types, anatomical structures and other biological entities."  [@url:"https://github.com/chanzuckerberg/single-cell-curation/blob/main/schema/3.0.0/schema.md"]. An ontology, as used here, is a formal computational representation of reality, which tries to represent each concept (and their relations) as precisely as possible.  [@wikidata:Q105870680]  

The Gene Ontology is probably the most well known biomedical ontology; it describes (among other things) different classes of biological process, related to each_other by "is_a" and "part_of relations. [@wikidata:Q104130127] [@wikidata:Q23781406]. The Gene Ontology is part of a much larger effort to formalize concepts across biology: the Open Biomedical and Biological Ontologies (OBO) Foundry. [@wikidata:Q19671692]
Created in 2007, the OBO Foundry is a hub of biomedical ontologies that sets guidelines for the design and construction of high-quality ontologies. 
The initial OBO Foundry united several independent ontologies, such as the Cell Ontology (CL), the Disease Ontology (DO) and the Protein Ontology (PRO) under a common framework, a great progress towards interoperability. 

<!-- Add paragraph on the usage of the Cell Ontology -->

The Cell Ontology was first described in 2005 [@wikidata:Q21184168] and was oriented both at creating a species-neutral classification of cells and
for researchers to "learn a considerable amount about that cell type and its relationships to other biological objects".[@wikidata:Q21184168]
The collaborative project gradually evolved and changed its design and scope to fit new needs. 
By 2011, a need for computable definitions led to an advance in the number and quality of immune cell types represented in CL. [@wikidata:Q33786317] 
It also included the addition of species-specific cell types to handle better marker-based definitions, usually presented at the species level. [@wikidata:Q33786317] 
Further developments over the years included both technical improvements and the addition of new cell types. 
By the time of the last official CL publication, in 2016, it contained approximately 2,200 classes.   [@wikidata:Q36067763]  
Currently, the Cell Ontology is growing as a resource for the Human Cell Atlas and in providing identifiers for cell types [@wikidata:Q109755180] and presents over 2500 classes of cells.


Ontologies are powerful, but require a high degree of technical expertise to get started. 
Recently, a new approach for formal knowledge representation arose with the dawn of collaborative knowledge graphs.
Wikidata, the collaborative knowledge graph of the Wikimedia foundation, allows users to contribute with classes and statements, in the same spirit of Wikipedia and share its "epistemic virtues, like power, speed and availability. [@wikidata:Q101955295]
It is powerful because of its large community of contributors. With a community of more than 46,000 active monthly editors and 420 million monthly views growing, it is able to cover a much wider number of concepts than any user individually. [@wikidata:Q118130164]
It is fast, because one does not need to install any software or ask for permissions to update it: any user can simply do it via a web interface. 
That speed makes it easier for newcomers to join and contribute, in contrast to OBO Foundry ontologies, which require extensive training on semantics and knowledge of Git/GitHub for contributions. 
Finally, the information on Wikidata is available via an user interface, via a SPARQL query service and as large, full-size database dumps, providing full extent reusability. Its CC0 public domain license waiver guarantees this reusability in any settings.[@wikidata:Q118130164]
The Wikidata model has been so sucessfull that Google decided to migrate its own knowledge base, Freebase, fully into Wikidata.[@wikidata:Q24074986] Wikidata has now been integrate into workflows by organizations like Amazon, OpenAI, Twitter, Apple, The Met and Smithsonian museums and more. [@wikidata:Q118130164]

Several advances towards biological data integration and biological data analysis in Wikidata have been made so far, yielding positive results [@doi:10.1101/031971] [@wikidata:Q87830400] and showcasing its potential for bioinformatics-related analyses, such as drug repurposing and ID conversion [@doi:10.7554/eLife.52614]. 
Wikidata has been proposed as a unified base to gather and distribute biomedical knowledge, with more than 50 000 human gene items indexed and hundreds of biomedical-related properties [@doi:10.1016/j.jbi.2019.103292].


This project aims to connect the advancements of collaborative knowledge modeling on Wikidata to the Human Cell Atlas scientific endeavor. We are reviewing the single-cell literature, refining and formalizing concepts for cell type delimitation, and exploring their application in the Wikidata database. At the same time, we are exploring how the Wikidata knowledge system can be integrated to the OBO Foundry to improve the coverage and quality of multiple ontologies. The goals of the project evolved in time and currently can be better summarized as:

* Analyze and complement the community-built data model to capture the main properties to describe a human cell on Wikidata 
* Study the concept of “cell type” and “cell state” in the context of data curation 
Develop a curation workflow for cell types on Wikidata and provide a comprehensive catalog of cell types 
* Study the intersections of Wikidata and bioinformatics in general, and the Human Cell Atlas in specific, and how the platform can intersect with the needs of scientific stakeholders.
* Develop tools and standard operating procedures to connect Wikidata and the OBO Foundry, as a stepping stone to improve the Human Cell Atlas curation efforts



# Achievements {.page_break_before}

In the project's third year, we focused on active exploration of the Wikidata platform as a contributor to the bioinformatics ecosystem, with a focus on the Human Cell Atlas. 
After formalizing a biocuration routine and building software to curate new cell types from the literature to Wikidata, we dedicated time to consolidating Wikidata as a state-of-the-art reference database for cells, leading to a catalog of over 6000 cell classes, as well as curating a complete mapping between the Cell Ontology and Wikidata. 
We also focused our effort on the metascientific potential of Wikidata, to represent not only information about cell types, but to leverage the graph structure to gain insights on the research community. 
As a byproduct of this endeavour, two python modules were produced: wdcuration, for on-demand fly-by curation of natural language terms to Wikidata, and PyOrcidator, a reconciler of information from ORCID Profiles to Wikidata. 
These tools were connected to curation efforts to map the landscape of Brazilian bioinformatics, as well as to provide insights in relation to particular academic events.  



## Biocuration of cell classes with Wikidata Bib  {.page_break_before}
### Introduction 

Annotation skills are part of formal academic training in the humanities  [@url:https://bibliotecadaeca.wordpress.com/2019/09/30/como-fazer-um-fichamento][@url:"https://www.youtube.com/playlist?list=PLAudUnJeNg4vWJhEJ_da26C-QW5qiS7uZ"]. 
An influential work in presenting methods for academic reading in the humanities is Umberto Eco's book "How to Write a Thesis" [@wikidata:Q3684178], which outlines not only _how_ to annotate the literature that basis an academic thesis, but also _why_ to do so. 
The book, written originally in 1977, is still influential today. 
Still, its theoretical scope (roughly the humanities) and its date preceding the digital era limits the extent to which it applies to the biomedical sciences. 

Notably, the need for an organized reading system for biocuration studies stems from a difference in methodology. 
In humanities, the main (if not sole) research material is the written text, the books and articles from which research stems—[@url:"https://www.youtube.com/playlist?list=PLAudUnJeNg4vWJhEJ_da26C-QW5qiS7uZ"].
In the biomedical sciences, including a large part of bioinformatics, the object of study is the natural world, observed via experimentation. 
Thus, naturally, scientific training focuses on experimentation and data analysis's theoretical and practical basis. 
With the boom of scientific articles, however, the scientific literature (and accompanying public datasets) already provide a strong material for sculpting scientific projects.
Thus, developing a methodology for academic reading tailored to the digital environment is a need. 

To address this gap, we developed  Wikidata Bib, a Wikidata-based framework for large scale curation of scientific articles. 
The framework is based on the metascientific coverage of Wikidata, as the platform also contains structured metadata for tens of millions of scientific articles, and tooling for adding new articles on demand.
### Methods
#### Wikidata Bib as a reading system 

The reading framework of Wikidata Bib is built upon a git repository integrated with GitHub, Python scripts, and SPARQL queries. 
The code is packaged into a python module to facilitate usage, using the Click library for providing a Command Line Interface for end-users (https://github.com/pallets/click).
After installing the package using the pip utility (https://pypi.org/), the user can use Wikidata Bib from the terminal as any other command-line utility. 
The basic commands available are described below:
 * `bib read` receives a Wikidata QID for an article and opens the article web page on a browser and opens a personalized notes document. It also updates the static files for the analytics dashboard, stored in the docs/ directory.
 * `bib pop`, which “pops” an article from a reading stash (manually and semi-automatically curated) at toread.yml and runs `bib read` for it 
 * `bib log` updates the git repository and adds, commits, and pushes notes and the dashboard to GitHub

The Wikidata bib framework is coupled with a discipline of daily reading.
The discipline is inspired by Robert Cecil Martin's description of Test Driven Development in the book "Clean Code", which includes not only a technical description but a _school of thought_ of how software development might be approached.  [@wikidata:Q109996684]
For the 2 years since the first usable version of Wikidata Bib, I've read one article about cell types (e.g. single-cell RNA-seq studies) and one article about biocuration (e.g. articles describing ontologies). I took notes on every article using the notetaking station displayed in Figure @fig: notetaking, and these notes are also made available in the GitHub repository.
The constancy of reading allows steady coverage of the relevant literature. 
While the discipline has worked for this research project, it is not required to use the Wikidata Bib system.

The Wikidata Bib framework also includes, whenever possible, an improvement of the metadata about the article on Wikidata. 
In @fig: notetaking B are shown the links included in the dashboard. 
A link to a Scholia [@wikidata:Q41799194] profile allows identification of related articles from a series of pre-made SPARQL queries probing bibliography data on Wikidata.
While Scholia provides an overview of a given article, it does not allow direct curation of the metadata.
For that, two links are provided, one to Wikidata and one to Author Disambiguator [@url:https://www.wikidata.org/wiki/Wikidata:Tools/Author_Disambiguator].
By accessing the Wikidata page for the entity, one can add new triples, for example, curating authors and topics of the article, which are then used by Scholia and by Wikidata Bib's dashboard. 
Author Disambiguator is a wrapper of an Wikimedia API that facilitates disambiguating author names to unique identifiers on Wikidata, thus feeding the public knowledge graph of publication and authors.  
Finally, a link to the article's DOI or full-text URL is provided and serves as a fallback when the automatic download fails. 
Of note, while the metadata curation has a technical benefit to Wikidata and the dashboard, it also plays a theoretical role. 
By curating metadata on authors, the user of Wikidata Bib can better understand the people they read, and expand their metascientific perspective on their domain of interest. 
Furthermore, by embedding the metascientific curation in the reading process WikidataBib directs the user to get acquainted with the people producing the science they read, thus contributing to a more complete perspective of the research process.

![Wikidata Bib's platform for note taking](https://raw.githubusercontent.com/lubianat/phd_figures/master/wikidata_bib/note_taking_station_annotated_with_links.png){#fig:notetaking}

The source code for Wikidata Bib is available at <https://github.com/lubianat/wikidata_bib>. 


#### Wikidata Bib for curation of cells to Wikidata

The Wikidata Bib system was originally devised to allow an overview of the single-cell RNA-seq and biocuration fields. 
However, during the process, we repurposed it for the biocuration of new cell classes in Wikidata. 
By fast-tracking reading, Wikidata Bib enables an efficient parsing of the literature and, thus, the identification of previously uncatalogued cell types.
Articles read with Wikidata Bib were screened for mentions of cell types absent from Wikidata. 
We considered a "cell type" as any class of cells described by a domain expert with evidence of the reality of its instances. When a mention of such a class appears in an article, I first verify Wikidata for the existence of a related class. 
Suppose that the class is absent from the platform. 
In that case, I enter a new class name (usually the name chosen by the domain expert in the reference article), alongside a superclass, and a QID in a Google Spreadsheet, as shown in @fig:biocuration_of_cells.

The information from the spreadsheet is pulled by a python script and processed locally with a series of dictionaries that match common terms to Wikidata IDs. 
In the example shown in Figure @fig:biocuration_of_cells, the string "endothelial cell" in hte spreadsheet was matched against a manually curated dictionary to the Wikidata entry [Q11394395](https://www.wikidata.org/wiki/Q11394395), the representation of that concept on Wikidata. 
After reconciling the data, the script uses the Wikidata Integrator python package [@url:https://github.com/SuLab/WikidataIntegrator] to insert the new entries on the Wikidata database. 
The code for integrating a Google Spreadsheet to Wikidata is available at <https://github.com/lubianat/wikidata_cell_curation>. 

![Wikidata Bib was coupled with a biocuration framework for cell types](https://raw.githubusercontent.com/lubianat/phd_figures/master/wikidata_bib/biocuration_of_cells.png){#fig:biocuration_of_cells width="85%"}

<!-- UPDATE THE STATISTICS 
Jupyter Notebook: https://colab.research.google.com/drive/1GvQXOs51_U8icdGMtKXMeLOXKM8pXWet
-->

### Results
![Statistics on cell type information on Wikidata as of 20/04/2023. A) Number of cell type items divided by taxon (P703, found in taxon, relation). The top 5 is shown. B) Number of cell type items created by each Wikidata user. The top 10 are shown. C-D) Total number of modifications of cell type items by each user, either total number (C) or the number of different edited items (D). The top 10 are shown.](https://raw.githubusercontent.com/lubianat/phd_figures/master/wikidata_cell_curation/statistics_20230420.png){#fig:wikidata_statistics_on_cell_classes width="85%"}

After the intense curation activity performed in this PhD project, Wikidata now contains 6102 subclasses of "cell ([Q7868](https://www.wikidata.org/wiki/Q7868))" as of 20 of April of 2023 (@fig:all_cells_network, @fig:wikidata_statistics_on_cell_classes). 
From those, 550 cell classes are specific for humans, and 318 are specific for mice.  
Currently Wikidata has more cell classes than the Cell Ontology, which lists around 2700 classes. 
It is worth noticing that classes on the Cell Ontology are added after careful consideration by ontologists and domain experts and should be considered of higher quality than the ones on Wikidata. 

From the 6102 cell classes on Wikidata, 5981 (98.0%) have been edited somehow by User:TiagoLubiana, and 4686 (76.8%) have been created by User:TiagoLubiana. 
Edits included adding multilanguage labels, connecting a dangling Wikipedia page to the cell subclass hierarchy, adding identifiers, images, markers, and other pieces of information. 
Approximatedly 430 hundred terms were added via manual curation based on PanglaoDB entries, while the remaining 4256 entries were created either via Wikidata's web interface or via the curation workflow described in this chapter. 

These statistics are demonstration of how the curation system used during this PhD project efficiently contributes to the status of cell type information on Wikidata.
Far from a flat curation, the cell classes on Wikidata were connected, when feasible, to each other and to other entities. 

![Overview of the subclass structure for cells in the Wikidata knowledge graph. The labels for the 10 most connect nodes are shown.](https://raw.githubusercontent.com/lubianat/phd_figures/master/wikidata_cell_curation/subclass_hierarchy_on_wikidata_20230512.png){#fig:all_cells_network}


The use of tens of Wikidata properties to describe those cells forms a large, multifaceted knowledge graph.
A sample of the expressiveness of the platform can be seem in figure @fig:top_relations_for_cell_types.png, which shows a schema for the most used properties in the platform.
Each of those relations can be queried in Wikidata's SPARQL endpoint, enabling complex, multi-hop queries navigating the biological landscape of Wikidata.
Furthermore, these cell classes are linked to identifiers in a variety of external platforms, providing a cross mapping and acquiring the role of a knowledge hub.


Thus, the contributions of this project to the Wikidata platform in the context of the life sciences is already "live" and actively contributing to the web of knowledge, both directly and undirectly, as sources such as OpenAI, Apple's Siri and the Google Knowledge Graph are known to use Wikidata in its operations. [@wikidata:Q118130164]
Wikidata's stable funding structure and long-term planning, alongside the copy-friendly CC0 license, guarantee the digital preservation of the knowledge curated, and its findability, accessibility, reusability and interoperability (FAIRness) for the foreseeable future.

![Top 10 relations used in Wikidata to represent cell classes as of May 12, 2023. The number of triples using each of the relations is shown under parenthesis.](https://raw.githubusercontent.com/lubianat/phd_figures/master/wikidata_cell_curation/top_10_properties_20230512.png){#fig:top_relations_for_cell_types.png}

| property | propertyLabel                           | counts |
|----------|-----------------------------------------|--------|
| wd:P7963 | Cell Ontology ID                        | 2635   |
| wd:P1402 | Foundational Model of Anatomy ID         | 889    |
| wd:P672  | MeSH tree code                           | 542    |
| wd:P6366 | Microsoft Academic ID                    | 505    |
| wd:P646  | Freebase ID                              | 387    |
| wd:P10283| OpenAlex ID                              | 277    |
| wd:P486  | MeSH descriptor ID                       | 269    |
| wd:P1417 | Encyclopædia Britannica Online ID        | 201    |
| wd:P3827 | JSTOR topic ID                           | 150    |
| wd:P1694 | Terminologia Histologica                 | 149    |

Table X: Top 10 links to identifiers community curated on cell classes on Wikidata. The identifier with larger coverage  is the Cell Ontology ID, designed and curated in the course of this PhD project.


However, even if Wikidata presents on itself a nice framework for community-encoding of knowledge into structured format, it would be naive to assume the Human Cell Atlas community would start using the platform in the short term.
Even though libraries and museums are increasingly using Wikidata as a source of identifiers

ADD REFERENCES

the life sciences community is still in the infancy of dealing with structure knownledge. 
Wikidata lacks the authoritativeness of a domain-specific governing body, such as the OBO Foundry, the Human Genome Nomenclature Consortium (HGNC), the International Catalog of Diseases (ICD), MeSH, and other label-and-identifier-providers for the life sciences.
Thus, while Wikidata plays a role in the knowledge representation ecosystem (with applications outside its own platform, e.g. as a mint for identifiers to use in nanopublications)

ADD REFERENCE

as we will discuss in the next sessions, we believe the more immediate contribution of Wikidata to the Human Cell Atlas will come indirectly, by improving the curation workflow in ontologies and providing insights into the metascience of events and communities. 


<!-- UPDATE THE STATISTICS -->



## Curation and mapping of Cell Ontology to Wikidata {.page_break_before}

### Introduction


While, in our experience, bioscientists are relutant on using resources like Wikipedia and Wikidata in professional settings, the Cell Ontology and other OBO Foundry ontologies are currently used strongly n the context of the Human Cell Atlas project.[@wikidata:Q109755180]
This realization lead to a decision on not promoting Wikidata use directly by the Human Cell Atlas community, but instead  
invest time in connecting Wikidata with the Cell Ontology as a stepping stone to wider Wikidata-OBO integration.

The connection of Wikidata with ontologies has a variety of potential benefits for the ecosystem. 
First, Wikidata is multilingual, and can provide identifiers in hundreds of languages. 
This is in stark contrast with the ontologies and controlled vocabularies world, extremely anglocentric.

Second, Wikidata has tight links to Wikipedia. 
Ontology consumers (such as CELLXGENE

ADD REFERENCE

and its ontology browser for single-cell RNA-seq datasets

ADD REFERENCE

) often find themselves in need of textual descriptions of the concepts, which is not the focus of ontology developers. 
Thus, Wikidata mappings can provide Wikipedia connections, increasing the possibilities for developers and curators using the ontology. 

Third, Wikidata has also links to many different resources and controlled vocabularies beyond Wikipedia. 
Even though most biocurated resources provide some degree of mapping (cross-references) to other resources, Wikidata plays the role of an identifier hub to connect ontologies with MeSH terms, the UMLS vocabulary, entries on libraries and encyclopedias and more.

Fourth: Wikidata's community presents a platform to validate and gather decentralized feedback on the platform with respect to new axioms and new classes, as well as on the consistency of existing classes. I
For example, in @fig:cl_multimappings we display one case in which the existence of multiple Wikidata-to-CL mappings allowed us to discover an inconsistency in CL in relation to common classification of cell types on Wikipedia, which separate "multinucleate cell" into two different entities, "coenocytic cell" and "syncitial cell".
The discovery led to a ticket on the Cell Ontology issue tracker, to be worked on in the future. 

![Wikidata's community curation helps Cell Ontology to improve. A) The entry for "multinucleate cell" showing a constraint violation, as the CL identifiers is also used in "syncitium". B) The CL entry for "multinucleate cell", showing "syncitium" as a synonym. C) The Wikipedia page, describing two types of multinucleate cells: syncitia and coenocytes. D) An open ticket in the Cell Ontology GitHub Issue Tracker to start the discussion towards normalizing the structure.](https://raw.githubusercontent.com/lubianat/phd_figures/master/cell_ontology/wikidata_multi_mappings_to_improve_cell_ontology.png){#fig:cl_multimappings width="85%"}

Finally, Wikidata provides an easy to enter structure to contribute, and if properly integrated to the Cell Ontology workflow, it can serve as a first-pass platform for new term suggestions.
While contributing to ontologies require download and configuration of the Protege platform, as well as familiarity with GitHub workflows, contributing to Wikidata has a much lower barrier. 
Wikidata, thus, serves as a gateway for ontology development, and can play a key role in the knowledge management ecosystem. 

### Methods
#### Wikidata and the Cell Ontology interplay

To map Cell Ontology on Wikidata, we proposed and got the approval of a specific Wikidata identifier for the Cell Ontology, the "Cell Ontology ID" (<https://www.wikidata.org/wiki/Property:P7963>).
IDs can be added to Wikidata entities and connected them to external databases enabling integrative SPARQL queries. 
Besides using the common Wikidata interface, one can crowd-curate identifiers via a 3rd-party service, Mix'N'Match, which provides a user-friendly framework for connecting identifier catalogues to Wikidata. [@url:http://magnusmanske.de/wordpress/?p=114], as seen in Figure @fig:mixn_match_cl. 
Logically, we created a Mix'N'Match catalogue for harmonizing Cell Ontology IDs to Wikidata (<https://mix-n-match.toolforge.org/#/catalog/4719>), harnessing the community support for the task. 

![Mix'N'Match curation system](https://pointstodots.files.wordpress.com/2021/09/image-17.png){#fig:mixnmatch_cl width="85%"}

#### The WDCuration Python package

A subproduct of the effort to curate cell types (and metascientific information, see the following chapter) was the development of an open-source Python package for on-demand curation of information to Wikidata. 
The WDCuration package (https://github.com/lubianat/wdcuration) implements a set of functions that provide the following functionality:
  * Given a term of interest and a JSON dictionary mapping strings to Wikidata IDS, lookup up the dictionary for an exact match
  * If the term is not in the dictionary, lookup Wikidata for it via ElasticSearch and return the best match for the term
  * Let the user decide if the match is correct OR enter a new, manually-accessed match
  * Update the JSON dictionary with a label-to-Wikidata mapping

The tool also allows tweaking of the Wikidata search by adding knowledge graph information, and including only "instances of --> cell type" or excluding all "instance of --> scientific article". 

The WDCuration package was instrumental in the mapping of cell terms in the Cell Ontology, as each term was checked against the database. About half the terms of the Cell Ontology (~1300) were already present on Wikidata, and the other 1300 were created automatically, with individual checks, with indiviual, statement-level references to the Cell Ontology.


### Results

As of early December 2022, more than 700 Cell Ontology IDs had been manually matched to Wikidata, both via the graphic user interface and with the Mix'n'Match platform. 
The integration already enables queries that harness the previously existing information on Wikidata for Cell Ontology-based applications. 
For example, one can query Wikidata items that have (1) a crossref to a CL ID (2) a picture in Wikimedia Commons (<https://w.wiki/4F6e>, Figure @fig:cl_images). 
The different possibilities of mutual benefit between the Cell Ontology and Wikidata will continue to be explored in the following years of this PhD project. 

![Entries on Wikidata with a depicting image and a Cell Ontology ID as of december 2022](https://user-images.githubusercontent.com/7917951/137942026-7645f368-d62a-4434-be05-083555cf0757.png){#fig:cl_images width="85%"}


The curation effort was expanded, with manual curation of the missing Wikidata - Cell Ontology links, including the creation of new classes for the missing Cell Ontology terms.
As of May 12th, 2023, Wikidata contains 2636 cross references to the Cell Ontology, covering virtually all terms in the ontology.
For the curation of the linkes, we developed a workflow that combined ROBOT (a tool for automating ontology workflows) [@wikidata:Q92260004] with a custom package for on-demand curation of natural language terms to Wikidata, wdcuration (https://github.com/lubianat/wdcuration).
The code for integration of CL to Wikidata is available at https://github.com/lubianat/cl_match_to_wikidata.


The curation effort had as an immediate outcome a list of cell types represented on Wikipedia, and thus of general notability, but missing from the Cell Ontology. 
The SPARQL query below outlines one of such results, by navigating the graph structure to extract neurons that do not have a CL identifier, but are present on English Wikipedia. 
Note that the query excludes sensory receptors, as these are not modelled by CL, as sometimes they are considered multicelluar structures and, in other cases, subcellular structures. 
The result of the query as of May 12 2023 is presented in the table below, but a live version of the query can be run in the Wikidata Query Service. (https://w.wiki/6hJT) 

```{sparql}
SELECT ?item ?label ?sitelink
WHERE 
{
  # Cell classes that do not have a link to the Cell Ontology
  ?item wdt:P279* wd:Q43054 .  
  # Excluding sensory receptors, as some classify as cells 
  # and others classify as anatomical structures.
  FILTER NOT EXISTS {?item wdt:P279* wd:Q729463 .} 
  MINUS {?item wdt:P7963 []. }
  
  ?sitelink schema:isPartOf <https://en.wikipedia.org/>;
     schema:about ?item .

  ?item rdfs:label ?label
  FILTER (lang(?label) = 'en')
}
LIMIT 10
```
Code Snippet X : 10 neuron types present on Wikipedia and Wikidata but not on the Cell Ontology

| Item | Label | English Wikipedia Page |
| --- | --- | --- |
| Q309082 | Mirror Neuron | [https://en.wikipedia.org/wiki/Mirror_neuron](https://en.wikipedia.org/wiki/Mirror_neuron) |
| Q863495 | Grid Neuron | [https://en.wikipedia.org/wiki/Grid_cell](https://en.wikipedia.org/wiki/Grid_cell) |
| Q934475 | Photosensitive Ganglion Cell | [https://en.wikipedia.org/wiki/Intrinsically_photosensitive_retinal_ganglion_cell](https://en.wikipedia.org/wiki/Intrinsically_photosensitive_retinal_ganglion_cell) |
| Q1476783 | Wide Dynamic Range Neuron | [https://en.wikipedia.org/wiki/Wide_dynamic_range_neuron](https://en.wikipedia.org/wiki/Wide_dynamic_range_neuron) |
| Q1756451 | Renshaw Cell | [https://en.wikipedia.org/wiki/Renshaw_cell](https://en.wikipedia.org/wiki/Renshaw_cell) |
| Q2384084 | Spindle Neuron | [https://en.wikipedia.org/wiki/Von_Economo_neuron](https://en.wikipedia.org/wiki/Von_Economo_neuron) |
| Q4944635 | Boundary Vector Neuron | [https://en.wikipedia.org/wiki/Boundary_cell](https://en.wikipedia.org/wiki/Boundary_cell) |
| Q4944637 | Drosophila Border Neuron | [https://en.wikipedia.org/wiki/Border_cells_(Drosophila)](https://en.wikipedia.org/wiki/Border_cells_(Drosophila)) |
| Q5064084 | Cerebellar Granule Neuron | [https://en.wikipedia.org/wiki/Cerebellar_granule_cell](https://en.wikipedia.org/wiki/Cerebellar_granule_cell) |
| Q5152118 | Command Neuron | [https://en.wikipedia.org/wiki/Command_neuron](https://en.wikipedia.org/wiki/Command_neuron) |

Table X: 10 neuron types present on Wikipedia and Wikidata but not on the Cell Ontology(ADD_SOURCE_LINK){#fig:cell_type_sources width="85%"}

## Mapping the metascience on bioinformatics onto Wikidata {.page_break_before}

### Introduction

During the development of this project we came to realize the potential of Wikidata to represent not only scientific concepts, but also metascientific concepts. 
Besides capturing information about the world, Wikidata has been developed as a platform to capture structured data on the sources for encoded statements . 
In other words, Wikidata became a citation repository, containing structured information on tens of millions of scientific articles.
This project was spearheaded by WikiCite, an organization dedicated to improve citations in the context of Wikimedia projects. 
The information encoded on Wikidata powers the provenance infrastructure of the platform, enabling queries to, for example, list the articles that were used as source of the cell types in the platform (@fig:cell_type_sources).

![Articles and databases most used as source for curation of cell types on Wikidata](ADD_SOURCE_LINK){#fig:cell_type_sources width="85%"}

The modelling of metadata about articles gradually expanded in scope, and Wikidata developed infrastructure to model other aspects of the publication landscape: theses, preprints, authors, institutions, research topics, academic software, conferences and more. 
One project, Scholia, rised as a platform showcasing Wikidata, SPARQL-based automatic profiles for different entities in academia. 

ADD REFERENCE

The insights provided by Scholia, such as co-author graphs and topic scores for institutions, triggered us to think about the biological knowledge graph in Wikidata in a broader sense, including not only the scientific concepts but also the players in the bioknowledge ecosystem.    

Given this potential of the platform, we invested time in expanding tooling and coverage of Wikidata for bioinformatics information, with a focus in the Brazilian bioinformatics community and in the context of the Human Cell atlas. 
In this chapter, we describe the PyOrcidator package, to integrate information from the ORCID platform to Wikidata on demand, a project to map the Brazilain bioinformatics landscape to Wikidata, a semantic catalog of USP Bioinformatics thesis and, finally an example of how to use the Wikidata infrastructure to get insights on particular academic events.


### Methods

Our process of building a metascientific knowledge graph and then displaying it to the community consisted of several steps, from data modelling to visualiazion. 
After identifying an analytical scope, we manually criated the core Wikidata entries for entities, adding aspects such as the location and parent institutions of programs, and start and end dates for academic events.  
Then, we used webscraping in Python to recover lists of related people, and manually reconciled the names to Wikidata, using both WDCuration and a set of other tools, such as the Wikipedia and Wikidata add-on for Google Sheets

ADD LINK

 and the Open Refine data curation platform.

ADD LINK

For each person, we run the PyOrcidator tool (described below) to update information on Wikidata, as well as other tools such as AuthorDisambiguator to disambiguate articles to their authors. 
Finally, to visualize the information, we wrote a series of SPARQL queries and/or used Scholia's standard SPARQL queries, to generate insights and visualizations on the graph.
Due to the ever-updating nature of the curation effort, we  made sure that all subprojects had  online, live dashboards either independently on GitHub Pages or on the Scholia platform.

#### PyOrcidator

One of the most important aspects of biomedical knowledge is the biomedical researcher. 
By having accurate metadata on people, we empower our community to better tailor its projects to the society.
For example, actionable metadata on affiliations, gender and (if public sources are available) ethnicity can help Equity, Diverstiy and Inclusion (EDI) efforts. 
In the context of the Human Cell Atlas, it can help us identifying biases and gaps in publications and events, and thus tweak the actions around the community to help the project to reach its goals. 
It can also help academic departments and programs to know more about its academic output, and use this data for improvement.

Currently, ORCID has risen as the core international standardized provider of academic curricula for individuals. 

ADD REFERENCE

Even though Currículo Lattes is the standard for academic curricula in Brazil, we focused on ORCID for its better international coverage, its open Application Program Interface, and its clear CC0 (public domain dedication) license, which enables reuse of the metadata. 
The ORCID API provides semi-structured information for every researcher, including DOIs for the listed publications. 
Most information provided, however, is in the form of natural language, meaning that users enter their affiliations and topics of research in free-format fields. 
That feature makes it harder, for example, to query ORCID for all members of a particular research institution, as names may be written in a myriad of different ways. 

The PyOrcidator tool combines parsing of the ORCID API with dictionary handling using WDCuration, enabling curators to map, on demand, the free labels of ORCID to the numeric identifiers of Wikidata.
It stores tree dictionaries, one for roles (e.g. "PhD Student", "Lead developer"), one for institutions (e.g. "University of São Paulo", "FioCruz Foundation") and one for topics (e.g. "Cell biology", "bioinformatics").
Users of the package clone the GitHub repository with the containing dictionaries, perform curation on demand and push the changes back to GitHub.
This decentralized curation enables gradual mapping of institution labels to Wikidata, effectively allowing reuse of curation effort.

For each ORCID, PyORCIDator generates a file in the Quickstatements 

ADD REFERENCE

format containing the triples that will be updated in the knowledge graph, including cross-identifiers present in ORCID (e.g. to Twitter and ResearchGate), the affiliations and education information, the topics studied and the publications for the author.
The PyORCIDator package is instrumental for the mapping of academic programs and conferences to Wikidata, enabling targeted curation of the metadata for the researchers of interest.

### The Landscape of Brazilian Bioinformatics

To exercise Wikidata as a framework for cataloguing scientific metadata, we set ourselves to the task of designing a map of the stakeholders in Brazilian bioinformatics. 

We created Wikidata entries for several bioinformatics programs in Brazil, and mapped the researchers affiliated to each of them on Wikidata. 
We also assumend that any researcher affiliated to a core bioinformatics program could also receive a triple stating "field of work --> bioinformatics".
For determining the people in scope of the project, we decided to filter for the following constraints: 

 1. People that have the triple field of work --> bioinformatics
 2. People that have some relation (employed by | affiliated to | educated at) an institution that has the triple "country --> Brazil". 

 We decided on that loose mapping to reach bioinformaticians in Brazil widely, even those that are not affiliated to a bioinformatics-only academic program. 
 Besides our individual curation of the academic programs, we organized a 2-day virtual event in november 2023 that gathered people from accross Brazil to share their perspectives and aid in the curation effort. 

The final product of the mapping is a live dashboard on the landscape of Brazilian bioinformatics that can be accessed at
https://lubianat.github.io/bioinfo_brasil/dashboard, highlighted in figure @fig:landscape_of_bioinformatics. 
The dashboard contains a series of SPARQL query results showcasing different facets of the Brazilian bioinformatics, such as the giant co-authorship component (@fig:landscape_of_bioinformatics A-B) with few separate communities, and the bias towards United States and European institutions for study and work. 


![Selected visualizations from the dashboard of the landscape of Brazilian bioinformatics. A) The co-authorship network of all brazilian bioinformatician (according to the previously outlined criteria). B) An inset of the graph, showing the high connectivity of the University of São Paulo community. Images are displayed whenever available under an open license in the Wikimedia Commons Database. For researchers without images, women are shown in green and man are shown in orange. Other genders or missing information would appear in white. C) The map of past an present affiliations of Brazilian bioinformaticians. All images displayed are screenshots of SPARQL query results available with live-updated data at https://lubianat.github.io/bioinfo_brasil/dashboard,](https://raw.githubusercontent.com/lubianat/phd_figures/master/metascience_on_wikidata/landscape_of_brazilian_bioinformatics.png){#fig:landscape_of_bioinformatics width="85%"} 

#### USP Bioinformatics Thesis

Besides the mapping of the bioinformatics researcher, we dedicated time to model and gather insights on the theses and dissertations produced by students at the University of São Paulo Graduate Program in Bioinformatics (also available at https://lubianat.github.io/bioinfo_brasil/dashboard)
Metadata for each publications was parsed from the Teses USP repository into a curation framework, where committee members and topics were curated from free text into Wikidata identifiers. 
Each publication, then, was created as a new item on Wikidata containing the reconciled metadata, making them available for querying. 

In @fig:bioinformatics_theses A, we see "bioinformatics" as the common main topic, but also concepts such as "transcriptome", "metagenomics" and "single-nucleotide polymorphisms", denoting the variety of subjects within the scope of the program.  In @fig:bioinformatics_theses B, we note that Prof. Helder Nakaya, the supervisor of this project, is the person that most attended defenses of the program. This data does not discern between own students and invitations, and thus this bias needs to be taken into account. 

@fig:bioinformatics_theses C presents a co-participation in bioinformatics defense committee network. 
We reasoned that, similar to co-authorship graphs, a committee co-participation network could bring insights into the soft structures of science. 
In this network, the presence of smaller, disconnected subcomponents, such as the one highlighted in @fig:bioinformatics_theses D, highlight different communities of practice.
In this case, the 3 professors of the program in the subgraph, Prof. Júlia Pavan, Prof. Anatoli Iambartsev  and Prof. Antonio Galves are all from the Institute of Mathematics and Statistics, perhaps signaling a difference in the type of research performed and evaluated.


Besides gathering factual evidence, the open metascientific maps on Wikidata have the power to show light at hidden structures of science. 
It provides a democratic way to navigate the landscape of academic affinities: which people publish together, which ones don't? Which professors participate in committee thesis together? 
Obvious applications are the rational improvement of structures and the aid to detect fraudulent schemes. But the non-obvious applications are important too: by encoding the metascientific structure openly, newcomers and young scientists have a way to understand the inner details of the academic carreer, and thus have a better shot at succeeding. 

![Topics and committee members of USP Bionformatics Theses and dissertations. A) The top 10 topics via Teses USP of the thesis in the program. B) The 5 people that most participated in defenses of the program C) A co-participation in committee graph for the USP Bioinformatics program. Researchers affiliated to the program are shown in blue. D) An inset of the graph, showing a community disconnected from the giant component. Graphs are not directional, arrows are an artifact of the graph visualization in the Wikidata Query Service.](https://raw.githubusercontent.com/lubianat/phd_figures/master/metascience_on_wikidata/bioinformatics_theses.png){#fig:bioinformatics_theses width="85%"}


### Event-based curation 

With the end of the COVID-19 pandemic health emergency, academic conferences started to happen again. 
Academic events are at the core of modern scientific practice, providing grounds for mix and match of people, and new projects that combine expertises to advance science. 
The structuring of event-level information using state-of-the-art Linked Open Data standards can help participants, organizers and funders to benefit the most of those events. 
Co-author graphs of participants and speakers, for example, can help us to identify opportunities for collaboration. 
Metainformation on location and gender, on the other hand, can auxiliate organizers to improve events in terms of diversity.


#### Natal Bioinformatics Forum 2023

For this report, we took the example of a knowledge graph of the speakers at the Natal Bioinformatics Forum, an academic gathering that happend in Natal, Rio Grande do Norte, in March 2023. 

As with the academic programs, the information for speakers was scraped, reconciled to Wikidata, and curated on the platform, and made available in a dashboard at https://lubianat.github.io/natal_bioinformatics2wikidata/. 
In @fig:natal_bioinformatics A, we can observe the co-authorship relations of the speakers in the event. 
Prof. Ana Tereza Vasconcelos stems as a hub in the graph, providing bridges accross subcomponents. 
The meaning of this relations was made clear during her talk at the event - Prof. Ana Tereza is one of the pioneers in bioinformatics in Brazil, and has been publishing on the field for decades, with wide ranging collaborations.

The mapping of the event to Wikidata also enable a quick overview of the kinds of software the speakers used in their publications. 
Besides the imaging software ImageJ, we could see a bias towards R packages for dealing with transcriptomics, such as "edgeR", "DESeq2", "limma" and "affy", also illustrating a bit the inner practices of the community. 
Finally, the map of affiliations of the speakers shows a clear bias towards United States and Europe. 
Strikingly, Latin American institutions were absent from the academic history of the speakers, and even inside Brazil, we see 2 localized clusters, one in the south-southwest and the other in a small part of the northwest.
The affiliations maps are powerful tools for identifying geographic biases and, hopefully, addressing them in the future. 


![An overview of the speakers at the Natal Bioinformatics Forum 2023. A) The co-authorship network of the speakers at the event, excluding speakers with no connections. B) A bubble plot showing the pieces of software most used by the spearkers in publications, according to Wikidata. C) The map of past and present affiliations of the speakers at the event.](https://raw.githubusercontent.com/lubianat/phd_figures/master/metascience_on_wikidata/natal_bioinformatics.png){#fig:natal_bioinformatics width="85%"} 


### Discussion 

#### Contextualization with the Human Cell Atlas

While the metascientific analysis described here are of relevance to Brazilian bioinformatics, we reason that the same tools can be used to understand, and address where needed, gaps in the Human Cell Atlas. 
We have started curating the metadata of Human Cell Atlas Publications

ADD LINK

to Wikidata, creating a new possibility to look at biases (geographic and otherwise) in the project. 
This is specially important in the context of HCA, as one of its core missions is to provide an atlas that is representative of the human diversity. 
We are also currently mapping the speakers and poster presenters of the Human Cell Atlas General Meeting 2023 to Wikidata, hopefully bringing insights on the event and the HCA community.


# Overall Conclusion 

In summary, in this PhD project so far we explored how Wikidata can aid scientific progress in the context of the Human Cell Atlas and, in a larger perspective, of bioinformatics in general. 
We demonstrate the versatility of the linked open data structure of the platform, on itself an argument for its usage (specially in the context of education), as it provides a set of direct and indirect transferrable skills.
We explored the connection of scientific and metascientific data into the platform, and how this data can be used both directly (via SPARQL queries) and indirectly, by the embedding of Wikidata into the workflow of ontologies. 

Of note, in this process, we also built a series of tools and proof-of-concept experiments that highlight how Wikidata can be used for biocuration and metacuration.
In the meanwhile, we built the largest resource of species-neutral cell types, certainly a valuable resource for any scientist devoted to catalog the diversity of human cells.
While we are convinced of the benefits of Wikidata for the researcher landscapes, we also realize that for immediate impact, the Cell Ontology is the resource of reference for organizing the information about cell types. 
Thus, the natural next step to ensure all this efforts impacts the Human Cell Atlas is by developing tooling and operating procedures to connect Wikidata and OBO Foundry ontologies.

Lastly, for the last year of PhD studies, we will dedicate the time to reflect, visualize, analyse, and produce writings summarizing what has been done, thereby making sure the scientific advances here reported are clearly acessible by the research community.



# Chronogram

### 5.1. Chronogram

| Activity                                                            | 07/23 | 10/23 | 01/24 | 04/24 |
|---------------------------------------------------------------------|-------|-------|-------|-------|
| Improve integration of Wikidata into the Cell Ontology and OBO Foundry workflows | P     | P     | s     |       |
| Write up theoretical studies on cell types and states               | s     | P     |       |       |
| Write up a summary article on Wikidata and the Human Cell Atlas     | s     | P     | P     |       |
| Write the thesis                                                    | s     | s     | P     | P     |

    P: primary activity, s: secondary activity


## Participation in events

* Oct/2022 - Presented a keynote about Wikidata and COVID-19 on the Third Wikidata Workshop of the International Semantic Web Conferenece. (Virtual)
* Dec/2022 - Presented the mapping of USP Bioinformatics theses on Wikidata on the 20-Year Graduate Program in Bioinformatics of the University of São Paulo Workshop (São Paulo, Brazil)
* Mar/2023 - Taught 3  classes on a single-cell RNA-seq data analysis course in Fiocruz Bahia (Salvador, Brazil)
* Mar/2023 - Presented a class on Wikidata and OBO Foundry integration at the Ontology Summit 2023 (Virtual)
* Mar/2023 - Presented a Wikidata analysis of the speakers of the Natal Bioinformatics Forum at the Natal Bioinformatics Forum (Natal, Brazil)
* Apr/2023 - Attended by fully-funded invitation the  Chan Zuckerberg Initiative Workshop on Open Science and Computational Biology in Latin America (Buenos Aires, Argentina)
* Apr/2023 - Presented a talk on the curation of cell types on Wikidata at Biocuration 2023 (Padua, Italy)
* May/2023 - (scheduled) Attending by fully-funded invitation the Wikimedia Hackathon, participating in training and coding activities with Wikidata core developers and improving software to add information to Wikidata (Athens, Greece) 
* Jul/2023 - (scheduled) Attending the Human Cell Atlas General Meeting, presenting a poster on theoretical considerations of the nature of cell types, with a partial travel award of 700 USD (Toronto, Canada) 

<!-- -->

# Preprints and articles  {.page_break_before}

## Pre-prints
- Using coexpression to explore cell-type diversity with the fcoex package (https://doi.org/10.1101/2021.12.07.471603)

- Guidelines for reporting cell types: the MIRACL standard
https://arxiv.org/abs/2204.09673

- WikiGOA: Gene set enrichment analysis based on Wikipedia and the Gene Ontology https://doi.org/10.1101/2022.09.15.508149

- ChatGPT/GPT-4 for computational biology (under review in Plos Computational Biology)

ADD PREPRINT LINK

## Peer-reviewed articles
- Complex Portal 2022: new curation frontiers (https://doi.org/10.1093/nar/gkab991)
- Unifying the identification of biomedical entities with the Bioregistry (https://doi.org/10.1038/s41597-022-01807-3)



## References {.page_break_before}

<!-- Explicitly insert bibliography here -->
<div id="refs"></div>
